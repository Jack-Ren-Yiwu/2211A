import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;
import org.apache.flink.streaming.api.functions.sink.filesystem.StreamingFileSink;
import org.apache.flink.core.fs.Path;
import org.apache.flink.streaming.api.functions.sink.filesystem.rollingpolicies.DefaultRollingPolicy;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class testb {

    public static void main(String[] args) throws Exception {

        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        // 1. 配置Kafka消费者属性
        Properties props = new Properties();
        props.setProperty("bootstrap.servers", "cdh01:9092");
        props.setProperty("group.id", "flink_group");

        // 2. 创建Kafka消费者（读取字符串）
        FlinkKafkaConsumer<String> kafkaConsumer = new FlinkKafkaConsumer<>(
                "ods_base_category1_topic",
                new SimpleStringSchema(),
                props);
        kafkaConsumer.setStartFromLatest(); // 从最新开始消费

        // 3. 从Kafka读取数据
        DataStream<String> kafkaStream = env.addSource(kafkaConsumer);

        // 4. 创建HDFS文件Sink
        final StreamingFileSink<String> sink = StreamingFileSink
                .forRowFormat(new Path("hdfs://cdh01:8020/user/flink/output/"),
                        (String element, java.io.OutputStream stream) -> {
                            stream.write((element + "\n").getBytes());
                        })
                .withRollingPolicy(
                        DefaultRollingPolicy.builder()
                                .withRolloverInterval(TimeUnit.MINUTES.toMillis(1))  // 1分钟切分，方便测试
                                .withInactivityInterval(TimeUnit.SECONDS.toMillis(10)) // 10秒无写入切分
                                .withMaxPartSize(1024 * 1024 * 16)                   // 10MB切分
                                .build())
                .withBucketCheckInterval(1000) // 每秒检查一次是否切分
                .build();


        // 5. 写数据到HDFS
        kafkaConsumer.setStartFromEarliest(); // 从最早的数据开始消费


        kafkaStream.addSink(sink);

        env.execute("Kafka To HDFS File Sink Job");
    }
}
