import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.table.api.EnvironmentSettings;
import org.apache.flink.table.api.Table;
import org.apache.flink.table.api.TableEnvironment;
import org.apache.flink.table.api.bridge.java.StreamTableEnvironment;
import org.apache.flink.table.catalog.hive.HiveCatalog;

public class test {
    public static void main(String[] args) throws Exception {
        // 设置Hadoop用户（根据实际情况修改）
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        EnvironmentSettings settings = EnvironmentSettings.newInstance().inStreamingMode().build();
        TableEnvironment tableEnv = TableEnvironment.create(settings);

        String kafkaSourceDDL = "CREATE TABLE kafka_source (" +
                "id INT, " +
                "name STRING, " +
                "ds STRING" +
                ") WITH (" +
                "'connector' = 'kafka', " +
                "'topic' = 'ods_base_category1_topic', " +
                "'properties.bootstrap.servers' = 'cdh01:9092,cdh02:9092', " +
                "'properties.group.id' = 'flink_consumer_group', " +
                "'scan.startup.mode' = 'earliest-offset', " +
                "'format' = 'json', " +
                "'json.ignore-parse-errors' = 'true'" +
                ")";

        tableEnv.executeSql(kafkaSourceDDL);

        Table result = tableEnv.sqlQuery("SELECT * FROM kafka_source LIMIT 3");
        result.execute().print();

    }
}
