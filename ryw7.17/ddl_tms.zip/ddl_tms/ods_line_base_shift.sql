-- �Զ����ɵ�Hive DDL�ű�
use tms;
-- Դ��: tms.line_base_shift
-- Ŀ���: ods_line_base_shift
-- ����ʱ��: 2025-07-11 20:54:37

CREATE TABLE IF NOT EXISTS ods_line_base_shift (
    id INT,
    line_id INT,
    start_time STRING,
    driver1_emp_id INT,
    driver2_emp_id INT,
    truck_id INT,
    pair_shift_id INT,
    is_enabled STRING,
    create_time STRING,
    update_time STRING,
    is_deleted STRING
)
PARTITIONED BY (dt STRING)
LOCATION 'hdfs://cdh01:8020//bigdata_warehouse/tms/ods_line_base_shift'

    TBLPROPERTIES (
    'orc.compress' = 'SNAPPY',
    'external.table.purge' = 'true'
    );
    