-- �Զ����ɵ�Hive DDL�ű�
use tms;
-- Դ��: tms.truck_info
-- Ŀ���: ods_truck_info
-- ����ʱ��: 2025-07-11 20:54:37

CREATE TABLE IF NOT EXISTS ods_truck_info (
    id INT,
    team_id INT,
    truck_no STRING,
    truck_model_id STRING,
    device_gps_id STRING,
    engine_no STRING,
    license_registration_date STRING,
    license_last_check_date STRING,
    license_expire_date STRING,
    picture_url STRING,
    is_enabled TINYINT,
    create_time STRING,
    update_time STRING,
    is_deleted STRING
)
PARTITIONED BY (dt STRING)
LOCATION 'hdfs://cdh01:8020//bigdata_warehouse/tms/ods_truck_info'

    TBLPROPERTIES (
    'orc.compress' = 'SNAPPY',
    'external.table.purge' = 'true'
    );
    