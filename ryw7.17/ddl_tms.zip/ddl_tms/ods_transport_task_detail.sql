-- �Զ����ɵ�Hive DDL�ű�
use tms;
-- Դ��: tms.transport_task_detail
-- Ŀ���: ods_transport_task_detail
-- ����ʱ��: 2025-07-11 20:54:37

CREATE TABLE IF NOT EXISTS ods_transport_task_detail (
    id INT,
    transport_task_id INT,
    order_id INT,
    sorter_emp_id INT,
    create_time STRING,
    update_time STRING,
    is_deleted STRING
)
PARTITIONED BY (dt STRING)
LOCATION 'hdfs://cdh01:8020//bigdata_warehouse/tms/ods_transport_task_detail'

    TBLPROPERTIES (
    'orc.compress' = 'SNAPPY',
    'external.table.purge' = 'true'
    );
    