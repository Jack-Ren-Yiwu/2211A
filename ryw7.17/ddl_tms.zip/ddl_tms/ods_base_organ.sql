-- �Զ����ɵ�Hive DDL�ű�
use tms;
-- Դ��: tms.base_organ
-- Ŀ���: ods_base_organ
-- ����ʱ��: 2025-07-11 20:54:37

CREATE TABLE IF NOT EXISTS ods_base_organ (
    id INT,
    org_name STRING,
    org_level INT,
    region_id INT,
    org_parent_id INT,
    points STRING,
    create_time STRING,
    update_time STRING,
    is_deleted STRING
)
PARTITIONED BY (dt STRING)
LOCATION 'hdfs://cdh01:8020//bigdata_warehouse/tms/ods_base_organ'

    TBLPROPERTIES (
    'orc.compress' = 'SNAPPY',
    'external.table.purge' = 'true'
    );
    