-- �Զ����ɵ�Hive DDL�ű�
use tms;
-- Դ��: tms.truck_team
-- Ŀ���: ods_truck_team
-- ����ʱ��: 2025-07-11 20:54:37

CREATE TABLE IF NOT EXISTS ods_truck_team (
    id INT,
    name STRING,
    team_no STRING,
    org_id INT,
    manager_emp_id INT,
    create_time STRING,
    update_time STRING,
    is_deleted STRING
)
PARTITIONED BY (dt STRING)
LOCATION 'hdfs://cdh01:8020//bigdata_warehouse/tms/ods_truck_team'

    TBLPROPERTIES (
    'orc.compress' = 'SNAPPY',
    'external.table.purge' = 'true'
    );
    