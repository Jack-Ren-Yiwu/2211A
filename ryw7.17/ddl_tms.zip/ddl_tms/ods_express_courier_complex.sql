-- �Զ����ɵ�Hive DDL�ű�
use tms;
-- Դ��: tms.express_courier_complex
-- Ŀ���: ods_express_courier_complex
-- ����ʱ��: 2025-07-11 20:54:37

CREATE TABLE IF NOT EXISTS ods_express_courier_complex (
    id INT,
    courier_emp_id INT,
    complex_id INT,
    create_time STRING,
    update_time STRING,
    is_deleted STRING
)
PARTITIONED BY (dt STRING)
LOCATION 'hdfs://cdh01:8020//bigdata_warehouse/tms/ods_express_courier_complex'

    TBLPROPERTIES (
    'orc.compress' = 'SNAPPY',
    'external.table.purge' = 'true'
    );
    