-- �Զ����ɵ�Hive DDL�ű�
use tms;
-- Դ��: tms.express_task_delivery
-- Ŀ���: ods_express_task_delivery
-- ����ʱ��: 2025-07-11 20:54:37

CREATE TABLE IF NOT EXISTS ods_express_task_delivery (
    id INT,
    order_id INT,
    status STRING,
    org_id INT,
    org_name STRING,
    courier_emp_id INT,
    courier_name STRING,
    estimated_end_time STRING,
    start_delivery_time STRING,
    delivered_time STRING,
    is_rejected STRING,
    create_time STRING,
    update_time STRING,
    is_deleted STRING
)
PARTITIONED BY (dt STRING)
LOCATION 'hdfs://cdh01:8020//bigdata_warehouse/tms/ods_express_task_delivery'

    TBLPROPERTIES (
    'orc.compress' = 'SNAPPY',
    'external.table.purge' = 'true'
    );
    