-- �Զ����ɵ�Hive DDL�ű�
use tms;
-- Դ��: tms.line_base_info
-- Ŀ���: ods_line_base_info
-- ����ʱ��: 2025-07-11 20:54:37

CREATE TABLE IF NOT EXISTS ods_line_base_info (
    id INT,
    name STRING,
    line_no STRING,
    line_level STRING,
    org_id INT,
    transport_line_type_id STRING,
    start_org_id INT,
    start_org_name STRING,
    end_org_id INT,
    end_org_name STRING,
    pair_line_id INT,
    distance DECIMAL(10,2),
    cost DECIMAL(10,2),
    estimated_time INT,
    status STRING,
    create_time STRING,
    update_time STRING,
    is_deleted STRING
)
PARTITIONED BY (dt STRING)
LOCATION 'hdfs://cdh01:8020//bigdata_warehouse/tms/ods_line_base_info'

    TBLPROPERTIES (
    'orc.compress' = 'SNAPPY',
    'external.table.purge' = 'true'
    );
    