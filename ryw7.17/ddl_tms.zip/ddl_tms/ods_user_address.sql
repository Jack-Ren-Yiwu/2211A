-- �Զ����ɵ�Hive DDL�ű�
use tms;
-- Դ��: tms.user_address
-- Ŀ���: ods_user_address
-- ����ʱ��: 2025-07-11 20:54:37

CREATE TABLE IF NOT EXISTS ods_user_address (
    id INT,
    user_id INT,
    phone STRING,
    province_id INT,
    city_id INT,
    district_id INT,
    complex_id INT,
    address STRING,
    is_default TINYINT,
    create_time STRING,
    update_time STRING,
    is_deleted STRING
)
PARTITIONED BY (dt STRING)
LOCATION 'hdfs://cdh01:8020//bigdata_warehouse/tms/ods_user_address'

    TBLPROPERTIES (
    'orc.compress' = 'SNAPPY',
    'external.table.purge' = 'true'
    );
    