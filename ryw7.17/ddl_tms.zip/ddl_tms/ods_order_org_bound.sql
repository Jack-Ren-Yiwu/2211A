-- �Զ����ɵ�Hive DDL�ű�
use tms;
-- Դ��: tms.order_org_bound
-- Ŀ���: ods_order_org_bound
-- ����ʱ��: 2025-07-11 20:54:37

CREATE TABLE IF NOT EXISTS ods_order_org_bound (
    id INT,
    order_id INT,
    org_id INT,
    status STRING,
    inbound_time STRING,
    inbound_emp_id INT,
    sort_time STRING,
    sorter_emp_id INT,
    outbound_time STRING,
    outbound_emp_id INT,
    create_time STRING,
    update_time STRING,
    is_deleted STRING
)
PARTITIONED BY (dt STRING)
LOCATION 'hdfs://cdh01:8020//bigdata_warehouse/tms/ods_order_org_bound'

    TBLPROPERTIES (
    'orc.compress' = 'SNAPPY',
    'external.table.purge' = 'true'
    );
    