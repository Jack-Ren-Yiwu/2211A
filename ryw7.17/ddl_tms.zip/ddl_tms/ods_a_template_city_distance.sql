-- �Զ����ɵ�Hive DDL�ű�
use tms;
-- Դ��: tms.a_template_city_distance
-- Ŀ���: ods_a_template_city_distance
-- ����ʱ��: 2025-07-11 20:54:37

CREATE TABLE IF NOT EXISTS ods_a_template_city_distance (
    id INT,
    city_no1 INT,
    city_no2 INT,
    distance INT,
    remark STRING
)
PARTITIONED BY (dt STRING)
LOCATION 'hdfs://cdh01:8020//bigdata_warehouse/tms/ods_a_template_city_distance'

    TBLPROPERTIES (
    'orc.compress' = 'SNAPPY',
    'external.table.purge' = 'true'
    );
    