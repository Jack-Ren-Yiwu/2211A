-- �Զ����ɵ�Hive DDL�ű�
use tms;
-- Դ��: tms.base_region_info
-- Ŀ���: ods_base_region_info
-- ����ʱ��: 2025-07-11 20:54:37

CREATE TABLE IF NOT EXISTS ods_base_region_info (
    id INT,
    parent_id INT,
    name STRING,
    dict_code STRING,
    short_name STRING,
    create_time STRING,
    update_time STRING,
    is_deleted TINYINT
)
PARTITIONED BY (dt STRING)
LOCATION 'hdfs://cdh01:8020//bigdata_warehouse/tms/ods_base_region_info'

    TBLPROPERTIES (
    'orc.compress' = 'SNAPPY',
    'external.table.purge' = 'true'
    );
    