-- �Զ����ɵ�Hive DDL�ű�
use tms;
-- Դ��: tms.user_info
-- Ŀ���: ods_user_info
-- ����ʱ��: 2025-07-11 20:54:37

CREATE TABLE IF NOT EXISTS ods_user_info (
    id INT,
    login_name STRING,
    nick_name STRING,
    passwd STRING,
    real_name STRING,
    phone_num STRING,
    email STRING,
    head_img STRING,
    user_level STRING,
    birthday STRING,
    gender STRING,
    create_time STRING,
    update_time STRING,
    is_deleted STRING
)
PARTITIONED BY (dt STRING)
LOCATION 'hdfs://cdh01:8020//bigdata_warehouse/tms/ods_user_info'

    TBLPROPERTIES (
    'orc.compress' = 'SNAPPY',
    'external.table.purge' = 'true'
    );
    