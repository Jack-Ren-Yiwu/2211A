-- �Զ����ɵ�Hive DDL�ű�
use tms;
-- Դ��: tms.express_task_collect
-- Ŀ���: ods_express_task_collect
-- ����ʱ��: 2025-07-11 20:54:37

CREATE TABLE IF NOT EXISTS ods_express_task_collect (
    id INT,
    order_id INT,
    status STRING,
    org_id INT,
    org_name STRING,
    courier_emp_id INT,
    courier_name STRING,
    estimated_collected_time STRING,
    estimated_commit_time STRING,
    actual_collected_time STRING,
    actual_commit_time STRING,
    cancel_time STRING,
    remark STRING,
    create_time STRING,
    update_time STRING,
    is_deleted STRING
)
PARTITIONED BY (dt STRING)
LOCATION 'hdfs://cdh01:8020//bigdata_warehouse/tms/ods_express_task_collect'

    TBLPROPERTIES (
    'orc.compress' = 'SNAPPY',
    'external.table.purge' = 'true'
    );
    