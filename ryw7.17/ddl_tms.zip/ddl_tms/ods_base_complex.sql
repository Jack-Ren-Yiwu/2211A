-- �Զ����ɵ�Hive DDL�ű�
use tms;
-- Դ��: tms.base_complex
-- Ŀ���: ods_base_complex
-- ����ʱ��: 2025-07-11 20:54:37

CREATE TABLE IF NOT EXISTS ods_base_complex (
    id INT,
    complex_name STRING,
    province_id INT,
    city_id INT,
    district_id INT,
    district_name STRING,
    create_time STRING,
    update_time STRING,
    is_deleted STRING
)
PARTITIONED BY (dt STRING)
LOCATION 'hdfs://cdh01:8020//bigdata_warehouse/tms/ods_base_complex'

    TBLPROPERTIES (
    'orc.compress' = 'SNAPPY',
    'external.table.purge' = 'true'
    );
    