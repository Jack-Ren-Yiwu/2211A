-- �Զ����ɵ�Hive DDL�ű�
use tms;
-- Դ��: tms.transport_task_process
-- Ŀ���: ods_transport_task_process
-- ����ʱ��: 2025-07-11 20:54:37

CREATE TABLE IF NOT EXISTS ods_transport_task_process (
    id INT,
    transport_task_id INT,
    cur_distance DECIMAL(16,2),
    line_distance DECIMAL(16,2),
    create_time STRING,
    update_time STRING,
    is_deleted STRING
)
PARTITIONED BY (dt STRING)
LOCATION 'hdfs://cdh01:8020//bigdata_warehouse/tms/ods_transport_task_process'

    TBLPROPERTIES (
    'orc.compress' = 'SNAPPY',
    'external.table.purge' = 'true'
    );
    