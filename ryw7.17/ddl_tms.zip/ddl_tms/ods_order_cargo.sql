-- �Զ����ɵ�Hive DDL�ű�
use tms;
-- Դ��: tms.order_cargo
-- Ŀ���: ods_order_cargo
-- ����ʱ��: 2025-07-11 20:54:37

CREATE TABLE IF NOT EXISTS ods_order_cargo (
    id INT,
    order_id STRING,
    cargo_type STRING,
    volume_length INT,
    volume_width INT,
    volume_height INT,
    weight DECIMAL(16,2),
    remark STRING,
    create_time STRING,
    update_time STRING,
    is_deleted STRING
)
PARTITIONED BY (dt STRING)
LOCATION 'hdfs://cdh01:8020//bigdata_warehouse/tms/ods_order_cargo'

    TBLPROPERTIES (
    'orc.compress' = 'SNAPPY',
    'external.table.purge' = 'true'
    );
    