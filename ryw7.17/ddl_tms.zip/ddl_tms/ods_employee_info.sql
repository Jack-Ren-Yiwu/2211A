-- �Զ����ɵ�Hive DDL�ű�
use tms;
-- Դ��: tms.employee_info
-- Ŀ���: ods_employee_info
-- ����ʱ��: 2025-07-11 20:54:37

CREATE TABLE IF NOT EXISTS ods_employee_info (
    id INT,
    username STRING,
    password STRING,
    real_name STRING,
    id_card STRING,
    phone STRING,
    birthday STRING,
    gender STRING,
    address STRING,
    employment_date STRING,
    graduation_date STRING,
    education STRING,
    position_type STRING,
    create_time STRING,
    update_time STRING,
    is_deleted STRING
)
PARTITIONED BY (dt STRING)
LOCATION 'hdfs://cdh01:8020//bigdata_warehouse/tms/ods_employee_info'

    TBLPROPERTIES (
    'orc.compress' = 'SNAPPY',
    'external.table.purge' = 'true'
    );
    